import { StudentProfile, UserExamSubmission, RemediationPlan, Question } from '../types';
import { INITIAL_QUESTION_BANK } from '../data/curriculum';
import { COMPREHENSIVE_QUESTION_BANK } from '../data/comprehensiveQuestionBank';
import { MIDTERM_STANDARD_40_QUESTIONS } from '../data/midtermExamData';
import { WORD_FORM_QUIZ_QUESTIONS } from '../data/wordFormBank';
import { UNIT_1_2_3_WORKSHEET_QUESTIONS } from '../data/unit123ComprehensiveBank';
import { ADDITIONAL_BATCH_QUESTIONS } from '../data/additionalQuestionsBatch';
import { calculateEloChange, getEloTier } from '../utils/elo';

const PROFILE_KEY = 'em11_student_profile';
const SUBMISSIONS_KEY = 'em11_exam_submissions';
const REMEDIATION_KEY = 'em11_remediation_plan';
const STUDY_TIME_KEY = 'em11_study_minutes';
const QUESTION_BANK_KEY = 'em11_stored_question_bank';

export const DEFAULT_STUDENT_PROFILE: StudentProfile = {
  id: 'student-demo-1',
  name: 'Nguyễn Minh Quân',
  grade: 'Lớp 11 (THPT)',
  targetScore: 9.0,
  pairingCode: 'EM11-8629',
  createdAt: Date.now() - 14 * 86400000, // 14 days ago
  completedTestsCount: 3,
  totalStudyMinutes: 245,
  averageScore: 8.2,
  weakTopics: ['Thì Quá khứ đơn vs Hiện tại hoàn thành (Unit 1)', 'Word Form: sustain -> sustainable', 'Động từ khuyết thiếu (Unit 2)'],
  strongTopics: ['Phát âm đuôi -ed', 'Danh động từ V-ing (Unit 4)', 'Từ vựng Thành phố tương lai (Unit 3)'],
  elo: 1365,
  eloHistory: [
    {
      timestamp: Date.now() - 6 * 86400000,
      oldElo: 1300,
      newElo: 1363,
      delta: 63,
      score: 8.7,
      examTitle: 'Đề kiểm tra nhanh 15 phút (Đầu tuần)',
      tier: 'B1',
    },
    {
      timestamp: Date.now() - 3 * 86400000,
      oldElo: 1363,
      newElo: 1345,
      delta: -18,
      score: 4.8,
      examTitle: 'Luyện tập Ngữ pháp',
      tier: 'B1',
    },
    {
      timestamp: Date.now() - 1 * 86400000,
      oldElo: 1345,
      newElo: 1365,
      delta: 20,
      score: 8.0,
      examTitle: 'Đề thi thử Giữa kì I - Lần 1',
      tier: 'B1',
    },
  ],
};

export const INITIAL_DEMO_SUBMISSIONS: UserExamSubmission[] = [
  {
    id: 'sub-demo-1',
    examId: 'exam-quick-15',
    examTitle: 'Đề kiểm tra nhanh 15 phút (Đầu tuần)',
    timestamp: Date.now() - 6 * 86400000,
    durationSecondsSpent: 720,
    totalQuestions: 15,
    correctCount: 13,
    scoreOutOf10: 8.7,
    answers: {
      'q-ph-1': 'D',
      'q-st-1': 'C',
      'q-u1-1': 'B',
      'q-u1-2': 'B',
      'q-u1-3': 'B',
      'q-u2-1': 'B',
      'q-u2-2': 'C',
      'q-u3-1': 'A',
      'q-u3-2': 'B',
      'q-u4-1': 'B',
      'q-u5-1': 'B',
      'q-u6-1': 'C',
      'q-u7-1': 'B',
      'q-err-1': 'B', // wrong
      'q-u8-1': 'A', // wrong
    },
    questions: INITIAL_QUESTION_BANK.slice(0, 15),
    categoryBreakdown: {
      pronunciation: { correct: 1, total: 1 },
      stress: { correct: 1, total: 1 },
      grammar: { correct: 8, total: 9 },
      vocabulary: { correct: 2, total: 2 },
      error_identification: { correct: 0, total: 1 },
      sentence_transformation: { correct: 1, total: 2 },
    },
    unitBreakdown: {
      1: { correct: 3, total: 4 },
      2: { correct: 2, total: 2 },
      3: { correct: 3, total: 3 },
      4: { correct: 1, total: 1 },
      5: { correct: 1, total: 1 },
      6: { correct: 1, total: 1 },
      7: { correct: 1, total: 1 },
      8: { correct: 1, total: 2 },
    },
  },
  {
    id: 'sub-demo-2',
    examId: 'exam-midterm-1',
    examTitle: 'Đề thi thử Giữa kì I - Lần 1',
    timestamp: Date.now() - 3 * 86400000,
    durationSecondsSpent: 2100,
    totalQuestions: 20,
    correctCount: 16,
    scoreOutOf10: 8.0,
    answers: {},
    questions: INITIAL_QUESTION_BANK.slice(0, 20),
    categoryBreakdown: {
      grammar: { correct: 10, total: 12 },
      vocabulary: { correct: 3, total: 4 },
      pronunciation: { correct: 2, total: 2 },
      sentence_transformation: { correct: 1, total: 2 },
    },
    unitBreakdown: {
      1: { correct: 4, total: 5 },
      2: { correct: 3, total: 4 },
      3: { correct: 4, total: 5 },
      4: { correct: 2, total: 2 },
      8: { correct: 1, total: 2 },
    },
  },
  {
    id: 'sub-demo-3',
    examId: 'exam-midterm-1',
    examTitle: 'Đề thi thử Giữa kì I - Lần 2',
    timestamp: Date.now() - 1 * 86400000,
    durationSecondsSpent: 2280,
    totalQuestions: 20,
    correctCount: 18,
    scoreOutOf10: 9.0,
    answers: {},
    questions: INITIAL_QUESTION_BANK.slice(0, 20),
    categoryBreakdown: {
      grammar: { correct: 11, total: 12 },
      vocabulary: { correct: 4, total: 4 },
      pronunciation: { correct: 2, total: 2 },
      sentence_transformation: { correct: 1, total: 2 },
    },
    unitBreakdown: {
      1: { correct: 5, total: 5 },
      2: { correct: 4, total: 4 },
      3: { correct: 5, total: 5 },
    },
  },
];

export function getStudentProfile(): StudentProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) {
      const parsed: StudentProfile = JSON.parse(raw);
      if (typeof parsed.elo !== 'number') {
        parsed.elo = 1300;
      }
      if (!Array.isArray(parsed.eloHistory)) {
        parsed.eloHistory = DEFAULT_STUDENT_PROFILE.eloHistory;
      }
      return parsed;
    }
  } catch (e) {
    console.error('Error loading profile', e);
  }
  // Initialize default
  localStorage.setItem(PROFILE_KEY, JSON.stringify(DEFAULT_STUDENT_PROFILE));
  return DEFAULT_STUDENT_PROFILE;
}

export function saveStudentProfile(profile: StudentProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.error('Error saving profile', e);
  }
}

export function getExamSubmissions(): UserExamSubmission[] {
  try {
    const raw = localStorage.getItem(SUBMISSIONS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading submissions', e);
  }
  localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(INITIAL_DEMO_SUBMISSIONS));
  return INITIAL_DEMO_SUBMISSIONS;
}

export function saveExamSubmission(submission: UserExamSubmission): void {
  try {
    const profile = getStudentProfile();

    // Calculate Elo change according to exact score brackets and tiers
    if (!submission.eloChange) {
      const currentElo = profile.elo ?? 1300;
      submission.eloChange = calculateEloChange(currentElo, submission.scoreOutOf10);
    }

    const current = getExamSubmissions();
    const updated = [submission, ...current];
    localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(updated));

    // Update profile stats and Elo
    const totalCount = updated.length;
    const avg = updated.reduce((acc, s) => acc + s.scoreOutOf10, 0) / totalCount;
    profile.completedTestsCount = totalCount;
    profile.averageScore = parseFloat(avg.toFixed(1));
    profile.totalStudyMinutes += Math.round(submission.durationSecondsSpent / 60);

    if (submission.eloChange) {
      profile.elo = submission.eloChange.newElo;
      profile.eloHistory = [
        {
          timestamp: submission.timestamp,
          oldElo: submission.eloChange.oldElo,
          newElo: submission.eloChange.newElo,
          delta: submission.eloChange.delta,
          score: submission.scoreOutOf10,
          examTitle: submission.examTitle,
          tier: submission.eloChange.newTier,
        },
        ...(profile.eloHistory || []),
      ];
    }

    // Analyze mistakes from submission to refresh weak topics
    const wrongAnswers = Object.entries(submission.answers).filter(([qId, ans]) => {
      const detail = submission.gradingDetails?.find((d) => d.questionId === qId);
      if (detail !== undefined) return !detail.isCorrect;
      const q = submission.questions.find((item) => item.id === qId);
      return q && q.correctAnswer !== ans;
    });

    if (wrongAnswers.length > 0) {
      const newWeaks = wrongAnswers
        .map(([qId]) => {
          const q = submission.questions.find((item) => item.id === qId);
          return q ? `${q.topic} (Unit ${q.unit})` : '';
        })
        .filter(Boolean);

      const combined = Array.from(new Set([...newWeaks, ...profile.weakTopics])).slice(0, 5);
      profile.weakTopics = combined;
    }

    saveStudentProfile(profile);
  } catch (e) {
    console.error('Error saving submission', e);
  }
}

export function getRemediationPlan(): RemediationPlan | null {
  try {
    const raw = localStorage.getItem(REMEDIATION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

export function saveRemediationPlan(plan: RemediationPlan): void {
  try {
    localStorage.setItem(REMEDIATION_KEY, JSON.stringify(plan));
  } catch (e) {
    console.error('Error saving remediation plan', e);
  }
}

export function clearAllUserData(): void {
  localStorage.removeItem(PROFILE_KEY);
  localStorage.removeItem(SUBMISSIONS_KEY);
  localStorage.removeItem(REMEDIATION_KEY);
  localStorage.removeItem(STUDY_TIME_KEY);
  localStorage.removeItem('em11_used_question_fingerprints');
}

/**
 * Combines all default questions into a comprehensive seed pool
 */
export function getDefaultQuestionBank(): Question[] {
  const map = new Map<string, Question>();

  [
    ...ADDITIONAL_BATCH_QUESTIONS,
    ...UNIT_1_2_3_WORKSHEET_QUESTIONS,
    ...COMPREHENSIVE_QUESTION_BANK,
    ...INITIAL_QUESTION_BANK,
    ...MIDTERM_STANDARD_40_QUESTIONS,
    ...WORD_FORM_QUIZ_QUESTIONS,
  ].forEach((q) => {
    if (!map.has(q.id)) {
      map.set(q.id, q);
    }
  });

  return Array.from(map.values());
}

export function getStoredQuestionBank(): Question[] {
  const defaults = getDefaultQuestionBank();
  try {
    const raw = localStorage.getItem(QUESTION_BANK_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Build map with defaults to guarantee latest prompts, underlines, and added items
        const map = new Map<string, Question>();
        defaults.forEach((q) => map.set(q.id, q));
        // Also preserve user-created custom questions
        parsed.forEach((q: Question) => {
          if (!map.has(q.id)) {
            map.set(q.id, q);
          }
        });
        const merged = Array.from(map.values());
        if (merged.length !== parsed.length) {
          localStorage.setItem(QUESTION_BANK_KEY, JSON.stringify(merged));
        }
        return merged;
      }
    }
  } catch (e) {
    console.error('Failed to parse question bank from localStorage', e);
  }

  localStorage.setItem(QUESTION_BANK_KEY, JSON.stringify(defaults));
  return defaults;
}

export function saveStoredQuestionBank(questions: Question[]): void {
  try {
    localStorage.setItem(QUESTION_BANK_KEY, JSON.stringify(questions));
  } catch (e) {
    console.error('Failed to save question bank to localStorage', e);
  }
}

export function addCustomQuestion(q: Question): void {
  const current = getStoredQuestionBank();
  const updated = [q, ...current.filter((item) => item.id !== q.id)];
  saveStoredQuestionBank(updated);
}

export function updateCustomQuestion(q: Question): void {
  const current = getStoredQuestionBank();
  const updated = current.map((item) => (item.id === q.id ? q : item));
  saveStoredQuestionBank(updated);
}

export function deleteCustomQuestion(id: string): void {
  const current = getStoredQuestionBank();
  const updated = current.filter((item) => item.id !== id);
  saveStoredQuestionBank(updated);
}

export function resetQuestionBankToDefault(): Question[] {
  const defaults = getDefaultQuestionBank();
  saveStoredQuestionBank(defaults);
  return defaults;
}

// ==========================================
// EXPORT & IMPORT UTILITIES
// ==========================================

export function exportQuestionsToJSON(questions?: Question[]): string {
  const data = questions || getStoredQuestionBank();
  return JSON.stringify(data, null, 2);
}

export function exportQuestionsToCSV(questions?: Question[]): string {
  const data = questions || getStoredQuestionBank();
  const headers = [
    'id',
    'grade',
    'bookSeries',
    'unit',
    'topic',
    'questionType',
    'difficulty',
    'question',
    'options',
    'correctAnswer',
    'acceptableAnswers',
    'targetWord',
    'tenseName',
    'signalWords',
    'explanationVi',
  ];

  const escapeCSV = (val: any) => {
    if (val === undefined || val === null) return '""';
    const str = Array.isArray(val) ? val.join(' | ') : String(val);
    return `"${str.replace(/"/g, '""').replace(/\n/g, ' ')}"`;
  };

  const rows = data.map((q) => [
    escapeCSV(q.id),
    escapeCSV(q.grade),
    escapeCSV(q.bookSeries),
    escapeCSV(q.unit),
    escapeCSV(q.topic),
    escapeCSV(q.questionType),
    escapeCSV(q.difficulty),
    escapeCSV(q.question),
    escapeCSV(q.options),
    escapeCSV(q.correctAnswer),
    escapeCSV(q.acceptableAnswers),
    escapeCSV(q.targetWord),
    escapeCSV(q.tenseName),
    escapeCSV(q.signalWords),
    escapeCSV(q.explanationVi),
  ]);

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}

export function importQuestionsFromJSON(
  jsonText: string
): { success: boolean; count: number; error?: string } {
  try {
    const parsed = JSON.parse(jsonText);
    if (!Array.isArray(parsed)) {
      return { success: false, count: 0, error: 'Dữ liệu JSON phải là một mảng câu hỏi.' };
    }

    const current = getStoredQuestionBank();
    const map = new Map<string, Question>();
    current.forEach((q) => map.set(q.id, q));

    let addedCount = 0;
    parsed.forEach((item: any, idx: number) => {
      if (item && item.question && item.correctAnswer) {
        const id = item.id || `imported-q-${Date.now()}-${idx}`;
        const normalized: Question = {
          id,
          grade: item.grade || 11,
          bookSeries: item.bookSeries || 'Global Success',
          unit: Number(item.unit) || 1,
          topic: item.topic || 'General Topic',
          questionType: item.questionType || 'multiple_choice',
          question: item.question,
          options: Array.isArray(item.options) ? item.options : [],
          correctAnswer: String(item.correctAnswer),
          acceptableAnswers: Array.isArray(item.acceptableAnswers) ? item.acceptableAnswers : undefined,
          targetWord: item.targetWord,
          tenseName: item.tenseName,
          signalWords: item.signalWords,
          difficulty: item.difficulty || 'medium',
          explanationVi: item.explanationVi || 'Lời giải chi tiết',
          explanationEn: item.explanationEn,
        };
        map.set(id, normalized);
        addedCount++;
      }
    });

    const updated = Array.from(map.values());
    saveStoredQuestionBank(updated);
    return { success: true, count: addedCount };
  } catch (err: any) {
    return { success: false, count: 0, error: err.message || 'Lỗi định dạng JSON không hợp lệ' };
  }
}

export function importQuestionsFromCSV(
  csvText: string
): { success: boolean; count: number; error?: string } {
  try {
    const lines = csvText.split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (lines.length < 2) {
      return { success: false, count: 0, error: 'File CSV không có dữ liệu hợp lệ' };
    }

    // Simple robust CSV split respecting quotes
    const parseLine = (line: string): string[] => {
      const result: string[] = [];
      let cur = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') {
          if (inQuotes && line[i + 1] === '"') {
            cur += '"';
            i++;
          } else {
            inQuotes = !inQuotes;
          }
        } else if (c === ',' && !inQuotes) {
          result.push(cur.trim());
          cur = '';
        } else {
          cur += c;
        }
      }
      result.push(cur.trim());
      return result;
    };

    const headers = parseLine(lines[0]).map((h) => h.toLowerCase().replace(/[^a-z0-9]/g, ''));
    const qIdx = headers.indexOf('question');
    const aIdx = headers.indexOf('correctanswer');

    if (qIdx === -1 || aIdx === -1) {
      return { success: false, count: 0, error: 'File CSV thiếu cột "question" hoặc "correctAnswer"' };
    }

    const current = getStoredQuestionBank();
    const map = new Map<string, Question>();
    current.forEach((q) => map.set(q.id, q));

    let importedCount = 0;
    for (let i = 1; i < lines.length; i++) {
      const cols = parseLine(lines[i]);
      if (cols.length <= qIdx || !cols[qIdx]) continue;

      const questionText = cols[qIdx];
      const answer = cols[aIdx] || '';
      const idCol = headers.indexOf('id');
      const id = idCol !== -1 && cols[idCol] ? cols[idCol] : `csv-${Date.now()}-${i}`;

      const gradeCol = headers.indexOf('grade');
      const grade = gradeCol !== -1 && Number(cols[gradeCol]) ? (Number(cols[gradeCol]) as any) : 11;

      const seriesCol = headers.indexOf('bookseries');
      const bookSeries = seriesCol !== -1 && cols[seriesCol] ? (cols[seriesCol] as any) : 'Global Success';

      const unitCol = headers.indexOf('unit');
      const unit = unitCol !== -1 && Number(cols[unitCol]) ? Number(cols[unitCol]) : 1;

      const topicCol = headers.indexOf('topic');
      const topic = topicCol !== -1 && cols[topicCol] ? cols[topicCol] : 'Grammar & Vocabulary';

      const typeCol = headers.indexOf('questiontype');
      const questionType = typeCol !== -1 && cols[typeCol] ? (cols[typeCol] as any) : 'multiple_choice';

      const diffCol = headers.indexOf('difficulty');
      const difficulty = diffCol !== -1 && cols[diffCol] ? (cols[diffCol] as any) : 'medium';

      const optCol = headers.indexOf('options');
      const rawOptions = optCol !== -1 && cols[optCol] ? cols[optCol] : '';
      const options = rawOptions ? rawOptions.split(' | ').map((s) => s.trim()) : [];

      const targetWordCol = headers.indexOf('targetword');
      const targetWord = targetWordCol !== -1 && cols[targetWordCol] ? cols[targetWordCol] : undefined;

      const tenseCol = headers.indexOf('tensename');
      const tenseName = tenseCol !== -1 && cols[tenseCol] ? cols[tenseCol] : undefined;

      const signalCol = headers.indexOf('signalwords');
      const signalWords = signalCol !== -1 && cols[signalCol] ? cols[signalCol] : undefined;

      const expCol = headers.indexOf('explanationvi');
      const explanationVi = expCol !== -1 && cols[expCol] ? cols[expCol] : 'Lời giải chi tiết';

      const newQ: Question = {
        id,
        grade,
        bookSeries,
        unit,
        topic,
        questionType,
        difficulty,
        question: questionText,
        options,
        correctAnswer: answer,
        targetWord,
        tenseName,
        signalWords,
        explanationVi,
      };

      map.set(id, newQ);
      importedCount++;
    }

    const updated = Array.from(map.values());
    saveStoredQuestionBank(updated);
    return { success: true, count: importedCount };
  } catch (err: any) {
    return { success: false, count: 0, error: err.message || 'Lỗi xử lý file CSV' };
  }
}
