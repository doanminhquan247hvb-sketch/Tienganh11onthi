import { Question, ExamCategoryMode, GradeLevel, BookSeries } from '../types';
import { scoreWordFormAnswer } from './wordFormScorer';
import { WORD_FORM_QUIZ_QUESTIONS } from '../data/wordFormBank';

const USED_FINGERPRINTS_KEY = 'em11_used_question_fingerprints';

/**
 * Normalizes question text, answer, and target word into a consistent fingerprint.
 * Shuffling ABCD options does NOT alter this fingerprint.
 */
export function calculateQuestionFingerprint(q: {
  question: string;
  correctAnswer: string;
  targetWord?: string;
}): string {
  const normQ = (q.question || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const normA = (q.correctAnswer || '').toLowerCase().trim();
  const normT = (q.targetWord || '').toLowerCase().trim();
  return `${normQ}:::${normA}:::${normT}`;
}

export function getUsedQuestionFingerprints(): Set<string> {
  try {
    const raw = localStorage.getItem(USED_FINGERPRINTS_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) {
        return new Set(arr);
      }
    }
  } catch (e) {
    console.error('Failed to load used fingerprints', e);
  }
  return new Set();
}

export function markQuestionFingerprintsAsUsed(questions: Question[]): void {
  try {
    const current = getUsedQuestionFingerprints();
    questions.forEach((q) => {
      current.add(calculateQuestionFingerprint(q));
    });
    localStorage.setItem(USED_FINGERPRINTS_KEY, JSON.stringify(Array.from(current)));
  } catch (e) {
    console.error('Failed to save used fingerprints', e);
  }
}

export function clearUsedQuestionFingerprints(): void {
  localStorage.removeItem(USED_FINGERPRINTS_KEY);
}

/**
 * Shuffles options for MCQ questions and re-aligns correctAnswer ('A', 'B', 'C', 'D')
 */
export function shuffleMcqOptions(q: Question): Question {
  // Do not shuffle text-input questions (word_form, pure text entry)
  if (q.questionType === 'word_form') {
    return { ...q };
  }
  if (!q.options || q.options.length < 2) {
    return { ...q };
  }

  const rawCorrect = (q.correctAnswer || '').trim();
  const rawUpper = rawCorrect.toUpperCase();
  const expectedLower = q.expectedTextAnswer?.trim().toLowerCase();

  // Extract raw option text without prefix 'A. ', 'B. '
  const rawOptionsWithTruth = q.options.map((opt, idx) => {
    const letter = String.fromCharCode(65 + idx); // 'A', 'B', 'C', 'D'
    const cleanText = opt.replace(/^[A-D]\.\s*/i, '').trim();
    const cleanTextWithoutTags = cleanText.replace(/<[^>]+>/g, '').toLowerCase();

    const isCorrect =
      rawUpper === letter ||
      cleanTextWithoutTags === rawCorrect.toLowerCase() ||
      (!!expectedLower && cleanTextWithoutTags === expectedLower);

    return { text: cleanText, isCorrect };
  });

  // Fisher-Yates shuffle
  const shuffled = [...rawOptionsWithTruth];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  // Re-assign A, B, C, D
  let newCorrectLetter = 'A';
  let matchedCleanText = '';
  const newOptions = shuffled.map((item, idx) => {
    const letter = String.fromCharCode(65 + idx);
    if (item.isCorrect) {
      newCorrectLetter = letter;
      matchedCleanText = item.text.replace(/<[^>]+>/g, '').trim();
    }
    return `${letter}. ${item.text}`;
  });

  const acceptable = Array.from(
    new Set([
      ...(q.acceptableAnswers || []),
      newCorrectLetter,
      matchedCleanText,
      q.expectedTextAnswer || '',
    ])
  ).filter(Boolean);

  return {
    ...q,
    options: newOptions,
    correctAnswer: newCorrectLetter,
    expectedTextAnswer: q.expectedTextAnswer || matchedCleanText || undefined,
    acceptableAnswers: acceptable,
  };
}

/**
 * Generates a 100% randomized 40-question Midterm Exam adhering strictly to the official ma trận:
 * - 30 MCQ (7,5đ): 4 Phonetics (2 pronunciation + 2 stress), 18 General MCQ, 3 Sentence Ordering, 3 Reading, 2 Consultation
 * - 4 Tense Conjugations (1,0đ)
 * - 4 Word Form Transformations (1,0đ)
 * - 2 Modal Verb Order / Rewrites (0,5đ)
 * All MCQ options are 100% randomized & shuffled on each generation!
 */
export function generateRandomizedMidtermExam(pool: Question[]): GeneratedExamResult {
  const u123 = pool.filter((q) => [1, 2, 3].includes(q.unit));
  const fallback = pool;

  const shuffle = <T>(arr: T[]): T[] => {
    const res = [...arr];
    for (let i = res.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [res[i], res[j]] = [res[j], res[i]];
    }
    return res;
  };

  // 1. Phonetics: 2 pronunciation + 2 stress
  const prPool = u123.filter((q) => q.questionType === 'pronunciation');
  const stPool = u123.filter((q) => q.questionType === 'stress');
  const prChosen = shuffle(prPool.length >= 2 ? prPool : fallback.filter((q) => q.questionType === 'pronunciation')).slice(0, 2);
  const stChosen = shuffle(stPool.length >= 2 ? stPool : fallback.filter((q) => q.questionType === 'stress')).slice(0, 2);

  // 2. Standard MCQ (Grammar, Vocab, Error identification): 18 questions
  const mcPool = u123.filter((q) => ['multiple_choice', 'grammar', 'vocabulary', 'error_identification'].includes(q.questionType));
  const mcChosen = shuffle(mcPool.length >= 18 ? mcPool : fallback.filter((q) => ['multiple_choice', 'grammar', 'vocabulary', 'error_identification'].includes(q.questionType))).slice(0, 18);

  // 3. Sentence ordering (3 questions)
  const ordPool = u123.filter((q) => q.questionType === 'sentence_ordering');
  const ordChosen = shuffle(ordPool.length >= 3 ? ordPool : fallback.filter((q) => q.questionType === 'sentence_ordering')).slice(0, 3);

  // 4. Reading comprehension (3 questions)
  const rdPool = u123.filter((q) => q.questionType === 'reading');
  const rdChosen = shuffle(rdPool.length >= 3 ? rdPool : fallback.filter((q) => q.questionType === 'reading')).slice(0, 3);

  // 5. Consultation / communication exchange (2 questions)
  const csPool = u123.filter((q) => q.questionType === 'consultation');
  const csChosen = shuffle(csPool.length >= 2 ? csPool : fallback.filter((q) => q.questionType === 'consultation')).slice(0, 2);

  // Combined 30 MCQ questions for Part I
  const part1Raw = [...prChosen, ...stChosen, ...mcChosen, ...ordChosen, ...rdChosen, ...csChosen];

  // In case pool has fewer than 30, top up from general MCQ
  while (part1Raw.length < 30) {
    const filler = shuffle(mcPool)[0] || fallback[0];
    part1Raw.push(filler);
  }

  // Shuffle Part 1 questions
  const part1 = shuffle(part1Raw.slice(0, 30));

  // 6. Part II: Tense conjugation (4 questions)
  const tnPool = u123.filter((q) => q.questionType === 'tenses' || q.questionType === 'tense_form');
  const tnChosen = shuffle(tnPool.length >= 4 ? tnPool : fallback.filter((q) => q.questionType === 'tenses' || q.questionType === 'tense_form')).slice(0, 4);

  // 7. Part III: Word Form (4 questions)
  const wfPool = u123.filter((q) => q.questionType === 'word_form');
  const wfChosen = shuffle(wfPool.length >= 4 ? wfPool : fallback.filter((q) => q.questionType === 'word_form')).slice(0, 4);

  // 8. Part IV: Modal Verbs (2 questions)
  const mvPool = u123.filter((q) => q.questionType === 'modal_verb_order' || q.questionType === 'sentence_transformation');
  const mvChosen = shuffle(mvPool.length >= 2 ? mvPool : fallback.filter((q) => q.questionType === 'modal_verb_order' || q.questionType === 'sentence_transformation')).slice(0, 2);

  const rawCombined = [
    ...part1.map((q) => ({ ...q, sectionTitle: 'I. Trắc nghiệm khách quan (30 câu - 7,5 điểm)' })),
    ...tnChosen.map((q) => ({ ...q, sectionTitle: 'II. Chia thì của động từ trong ngoặc (4 câu - 1,0 điểm)' })),
    ...wfChosen.map((q) => ({ ...q, sectionTitle: 'III. Word Form (Biến đổi dạng từ - 4 câu - 1,0 điểm)' })),
    ...mvChosen.map((q) => ({ ...q, sectionTitle: 'IV. Viết lại câu / Sắp xếp Modal Verbs (2 câu - 0,5 điểm)' })),
  ];

  const now = Date.now();
  const randomizedQuestions: Question[] = rawCombined.map((item, idx) => {
    const cloned = {
      ...item,
      id: `${item.id}-rnd-${now}-${idx + 1}`,
      points: 0.25,
    };
    // Shuffle options for MCQ
    return shuffleMcqOptions(cloned);
  });

  const examCode = generateExamCode();
  const title = `Đề thi thử Giữa kì I (Ma trận 40 câu - Ngẫu nhiên 100%) • Mã ${examCode}`;

  return {
    examCode,
    title,
    questions: randomizedQuestions,
    isPoolDepleted: false,
    availableCount: pool.length,
    requestedCount: 40,
  };
}

export interface GenerateExamOptions {
  mode: ExamCategoryMode;
  questionCount: number;
  grade?: GradeLevel;
  bookSeries?: BookSeries;
  units?: number[];
  difficulty?: 'basic' | 'medium' | 'advanced' | 'mixed';
  deduplicate?: boolean;
  pool: Question[];
}

export interface GeneratedExamResult {
  examCode: string;
  title: string;
  questions: Question[];
  isPoolDepleted: boolean;
  availableCount: number;
  requestedCount: number;
}

/**
 * Creates unique Exam Code: ENG-YYYYMMDD-XXXX
 */
export function generateExamCode(): string {
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomHex = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `ENG-${dateStr}-${randomHex}`;
}

/**
 * Core exam generator with strict deduplication and empty-pool alert detection
 */
export function generateExamWithDeduplication(options: GenerateExamOptions): GeneratedExamResult {
  const {
    mode,
    questionCount,
    grade = 11,
    bookSeries = 'Global Success',
    units = [],
    difficulty = 'mixed',
    deduplicate = true,
    pool,
  } = options;

  const usedSet = deduplicate ? getUsedQuestionFingerprints() : new Set<string>();

  // Filter pool by mode
  let filtered = pool.filter((q) => {
    // Mode filtering
    if (mode === 'word_form') {
      if (q.questionType !== 'word_form') return false;
    } else if (mode === 'tenses') {
      if (q.questionType !== 'tenses' && q.questionType !== 'tense_form') return false;
    } else if (mode === 'multiple_choice') {
      const isMc = ['multiple_choice', 'pronunciation', 'stress', 'grammar', 'vocabulary', 'reading', 'cloze'].includes(q.questionType);
      if (!isMc) return false;
    }

    // Units filter (if provided)
    if (units.length > 0 && !units.includes(q.unit)) {
      return false;
    }

    // Difficulty filter
    if (difficulty !== 'mixed' && q.difficulty !== difficulty) {
      return false;
    }

    return true;
  });

  // If pool too small for specific grade, expand slightly while prioritizing current grade
  if (filtered.length === 0) {
    filtered = pool.filter((q) => {
      if (mode === 'word_form') return q.questionType === 'word_form';
      if (mode === 'tenses') return q.questionType === 'tenses' || q.questionType === 'tense_form';
      if (mode === 'multiple_choice') return q.options && q.options.length >= 2;
      return true;
    });
  }

  // Deduplication check
  const unusedList = filtered.filter((q) => !usedSet.has(calculateQuestionFingerprint(q)));
  const isPoolDepleted = unusedList.length < questionCount;

  // Selection list: use unused first, fallback to recycling if needed
  let candidates: Question[] = [...unusedList];
  if (candidates.length < questionCount) {
    // Include some recycled ones to fulfill requested count
    const alreadyUsed = filtered.filter((q) => usedSet.has(calculateQuestionFingerprint(q)));
    candidates = [...candidates, ...alreadyUsed];
  }

  // If still not enough, duplicate with unique IDs so the requested question count is met
  const shuffledCandidates = [...candidates].sort(() => 0.5 - Math.random());
  const selectedQuestions: Question[] = [];

  for (let i = 0; i < questionCount; i++) {
    const item = shuffledCandidates[i % shuffledCandidates.length];
    if (item) {
      const cloned = {
        ...item,
        id: `${item.id}-run-${Date.now()}-${i + 1}`,
      };
      // Randomize MCQ options order
      const finalized = shuffleMcqOptions(cloned);
      selectedQuestions.push(finalized);
    }
  }

  // Inject ~5% Modal Verb short sentence rewrite questions for general & combined modes
  if ((mode === 'multiple_choice' || mode === 'combined') && selectedQuestions.length >= 10) {
    const modalTargetCount = Math.max(1, Math.round(questionCount * 0.05)); // 5% rate
    const modalPool = pool.filter(
      (q) =>
        q.questionType === 'modal_verb_order' ||
        q.questionType === 'sentence_transformation' ||
        q.topic?.toLowerCase().includes('modal')
    );

    if (modalPool.length > 0) {
      const shuffledModal = [...modalPool].sort(() => 0.5 - Math.random());
      for (let m = 0; m < modalTargetCount && m < selectedQuestions.length; m++) {
        const modalItem = shuffledModal[m % shuffledModal.length];
        const replaceIdx = selectedQuestions.length - 1 - m;
        selectedQuestions[replaceIdx] = shuffleMcqOptions({
          ...modalItem,
          id: `${modalItem.id}-mv5p-${Date.now()}-${m + 1}`,
        });
      }
    }
  }

  const examCode = generateExamCode();
  let titleModeVi = 'Đề thi trắc nghiệm ABCD';
  if (mode === 'word_form') titleModeVi = 'Bài tập Word Form (Biến đổi từ loại)';
  else if (mode === 'tenses') titleModeVi = 'Bài tập Chia thì Tiếng Anh';
  else if (mode === 'combined') titleModeVi = 'Đề thi tổng hợp các dạng bài';

  const title = `${titleModeVi} • ${questionCount} câu • Mã ${examCode}`;

  return {
    examCode,
    title,
    questions: selectedQuestions,
    isPoolDepleted,
    availableCount: unusedList.length,
    requestedCount: questionCount,
  };
}

/**
 * Generates an exam testing the 8 board words with user-selected question counts: 5, 7, 10, or 12 questions.
 */
export function generateBoard8WordFormExam(count: number = 8): GeneratedExamResult {
  const safeCount = Math.max(5, count);
  const shuffled = [...WORD_FORM_QUIZ_QUESTIONS].sort(() => 0.5 - Math.random());
  const selected: Question[] = [];

  const pointsPerQuestion = parseFloat((10 / safeCount).toFixed(3));
  const now = Date.now();

  for (let i = 0; i < safeCount; i++) {
    const item = shuffled[i % shuffled.length];
    selected.push({
      ...item,
      id: `${item.id}-b8-${now}-${i + 1}`,
      points: pointsPerQuestion,
      sectionTitle: `Chuyên đề 8 từ Word Form (${safeCount} câu - Thang điểm 10)`,
    });
  }

  const examCode = generateExamCode();
  const title = `Chuyên Đề Word Form 8 Từ Đã Học (${safeCount} câu) • Mã ${examCode}`;

  return {
    examCode,
    title,
    questions: selected,
    isPoolDepleted: false,
    availableCount: WORD_FORM_QUIZ_QUESTIONS.length,
    requestedCount: safeCount,
  };
}

/**
 * Generates an authentic multiple-choice Vocabulary Exam for Units 1, 2, 3 with user-selected question counts: 15, 20, 25, 30, or 40 questions.
 */
export function generateUnit123VocabularyExam(count: number = 20, pool: Question[]): GeneratedExamResult {
  const safeCount = [15, 20, 25, 30, 40].includes(count) ? count : 20;

  // Filter pool for Unit 1, 2, 3 vocabulary & multiple choice questions
  const u123Vocab = pool.filter(
    (q) =>
      [1, 2, 3].includes(q.unit) &&
      ['vocabulary', 'multiple_choice', 'grammar', 'reading', 'cloze'].includes(q.questionType) &&
      q.options &&
      q.options.length >= 2
  );

  const fallback = pool.filter((q) => q.options && q.options.length >= 2);
  const candidatePool = u123Vocab.length >= safeCount ? u123Vocab : fallback;

  const shuffled = [...candidatePool].sort(() => 0.5 - Math.random());
  const selected: Question[] = [];
  const pointsPerQuestion = parseFloat((10 / safeCount).toFixed(3));
  const now = Date.now();

  for (let i = 0; i < safeCount; i++) {
    const item = shuffled[i % shuffled.length];
    const cloned = {
      ...item,
      id: `${item.id}-u123v-${now}-${i + 1}`,
      points: pointsPerQuestion,
      sectionTitle: `Trắc nghiệm Từ vựng Unit 1, 2, 3 (${safeCount} câu - Thang điểm 10)`,
    };
    selected.push(shuffleMcqOptions(cloned));
  }

  const examCode = generateExamCode();
  const title = `Chuyên Đề Trắc Nghiệm Từ Vựng Unit 1, 2, 3 (${safeCount} câu) • Mã ${examCode}`;

  return {
    examCode,
    title,
    questions: selected,
    isPoolDepleted: false,
    availableCount: u123Vocab.length,
    requestedCount: safeCount,
  };
}

