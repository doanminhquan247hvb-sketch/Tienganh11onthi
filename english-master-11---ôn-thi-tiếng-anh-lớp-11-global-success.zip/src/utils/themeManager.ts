export interface ThemeSettings {
  wallpaperEnabled: boolean;
  wallpaperUrl: string;
  wallpaperName: string;
  wallpaperSizeMb?: number;
  overlayOpacity: number; // default 0.80 (80% opacity dimming)
  blurAmount: 'none' | 'sm' | 'md' | 'lg';
}

const THEME_STORAGE_KEY = 'em11_theme_settings';

export const CURATED_WALLPAPERS = [
  {
    id: 'cyber-city',
    name: 'Thành Phố Tương Lai (Unit 3)',
    category: 'Future Cities',
    url: 'https://images.unsplash.com/photo-1508873696983-2df5293cbdaf?q=85&w=3840&auto=format&fit=crop',
    approxSizeMb: 24.5,
    previewColor: '#0f172a',
  },
  {
    id: 'smart-school',
    name: 'Trường THPT Thông Minh',
    category: 'Classroom',
    url: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?q=85&w=3840&auto=format&fit=crop',
    approxSizeMb: 28.2,
    previewColor: '#1e1b4b',
  },
  {
    id: 'green-eco',
    name: 'Sinh Thái Xanh Bền Vững (Unit 1)',
    category: 'Eco Nature',
    url: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=85&w=3840&auto=format&fit=crop',
    approxSizeMb: 32.1,
    previewColor: '#064e3b',
  },
  {
    id: 'digital-library',
    name: 'Thư Viện Học Thuật 4.0',
    category: 'Library',
    url: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=85&w=3840&auto=format&fit=crop',
    approxSizeMb: 21.8,
    previewColor: '#1e293b',
  },
  {
    id: 'deep-space',
    name: 'Công Nghệ AI & Vũ Trụ Số',
    category: 'Tech Abstract',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=85&w=3840&auto=format&fit=crop',
    approxSizeMb: 26.4,
    previewColor: '#020617',
  },
];

export const DEFAULT_THEME_SETTINGS: ThemeSettings = {
  wallpaperEnabled: true,
  wallpaperUrl: CURATED_WALLPAPERS[0].url,
  wallpaperName: CURATED_WALLPAPERS[0].name,
  wallpaperSizeMb: CURATED_WALLPAPERS[0].approxSizeMb,
  overlayOpacity: 0.05, // mờ 5% theo yêu cầu
  blurAmount: 'none',
};

export function getStoredThemeSettings(): ThemeSettings {
  try {
    const raw = localStorage.getItem(THEME_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_THEME_SETTINGS,
        ...parsed,
        overlayOpacity: 0.05, // enforce 5% opacity
      };
    }
  } catch (e) {
    console.error('Failed to parse theme settings', e);
  }
  return DEFAULT_THEME_SETTINGS;
}

export function saveThemeSettings(settings: ThemeSettings): void {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(settings));
    window.dispatchEvent(new CustomEvent('em11_theme_updated', { detail: settings }));
  } catch (e) {
    console.error('Failed to save theme settings', e);
  }
}
