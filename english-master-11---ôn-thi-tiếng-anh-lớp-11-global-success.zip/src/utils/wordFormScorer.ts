/**
 * Word Form comparison & Levenshtein distance scoring algorithm
 * Implements the exact scoring specifications:
 * - 5 or 7 questions: maxScore = 10 / N. 1 char error = -0.3. 2+ char error = -0.3 * charErrors.
 * - 10, 12 or more questions: maxScore = 10 / N. 1 char error = -0.15. 2+ char error = -0.15 * charErrors.
 * - No negative scores per question. Total score capped at 0 - 10.
 * - Normalizes case & whitespace.
 * - Checks equivalent acceptable answers (e.g. US/UK spellings or valid derivations).
 */

export interface WordFormScoreResult {
  userAnswer: string;
  matchedAnswer: string;
  isExact: boolean;
  isAcceptable: boolean;
  charErrors: number;
  penalty: number;
  scoreAwarded: number;
  maxScore: number;
  explanation: string;
  diffBreakdown: string;
  // Aliases for convenient property access
  score: number;
  maxPossible: number;
  feedbackVi: string;
  isCorrect: boolean;
}

/**
 * Standard Levenshtein distance calculating minimum number of single-character edits
 * (insertions, deletions or substitutions) required to change s1 into s2.
 */
export function getLevenshteinDistance(s1: string, s2: string): number {
  const m = s1.length;
  const n = s2.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (s1[i - 1] === s2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(
          dp[i - 1][j],    // deletion
          dp[i][j - 1],    // insertion
          dp[i - 1][j - 1] // substitution
        );
      }
    }
  }

  return dp[m][n];
}

/**
 * Normalizes input: lowercases, trims, and collapses multiple spaces.
 */
export function normalizeWord(word: string): string {
  if (!word) return '';
  return word.toLowerCase().trim().replace(/\s+/g, ' ');
}

/**
 * Evaluates a student's Word Form answer against standard & equivalent answers
 */
export function scoreWordFormAnswer(
  rawInput: string,
  targetAnswerOrList: string | string[],
  totalQuestionsInExam: number,
  extraAcceptableAnswers?: string[]
): WordFormScoreResult {
  const maxScore = parseFloat((10 / Math.max(1, totalQuestionsInExam)).toFixed(3));
  const normalizedUser = normalizeWord(rawInput);

  let acceptableAnswers: string[] = [];
  if (Array.isArray(targetAnswerOrList)) {
    acceptableAnswers = [...targetAnswerOrList];
  } else if (typeof targetAnswerOrList === 'string') {
    acceptableAnswers = [targetAnswerOrList];
  }
  if (Array.isArray(extraAcceptableAnswers)) {
    acceptableAnswers = [...acceptableAnswers, ...extraAcceptableAnswers];
  }

  // Deduplicate
  acceptableAnswers = Array.from(new Set(acceptableAnswers.filter(Boolean)));
  if (acceptableAnswers.length === 0) {
    acceptableAnswers = [''];
  }

  if (!normalizedUser) {
    const defaultTarget = acceptableAnswers[0] || '';
    return {
      userAnswer: '',
      matchedAnswer: defaultTarget,
      isExact: false,
      isAcceptable: false,
      charErrors: defaultTarget.length,
      penalty: maxScore,
      scoreAwarded: 0,
      maxScore,
      explanation: 'Chưa nhập câu trả lời.',
      diffBreakdown: 'Bỏ trống',
      score: 0,
      maxPossible: maxScore,
      feedbackVi: `Chưa điền câu trả lời. Đáp án chuẩn: "${defaultTarget}".`,
      isCorrect: false,
    };
  }

  const normalizedAnswers = acceptableAnswers.map(normalizeWord);

  // 1. Check exact match with any acceptable answer
  const exactIndex = normalizedAnswers.findIndex((ans) => ans === normalizedUser);
  if (exactIndex !== -1) {
    return {
      userAnswer: rawInput.trim(),
      matchedAnswer: acceptableAnswers[exactIndex],
      isExact: true,
      isAcceptable: true,
      charErrors: 0,
      penalty: 0,
      scoreAwarded: maxScore,
      maxScore,
      explanation: 'Chính xác 100%! Đạt điểm tối đa.',
      diffBreakdown: 'Chính xác',
      score: maxScore,
      maxPossible: maxScore,
      feedbackVi: 'Chính xác 100%! Đạt điểm tối đa.',
      isCorrect: true,
    };
  }

  // 2. Find the best matching acceptable answer with minimal Levenshtein distance
  let minDistance = Infinity;
  let bestMatch = acceptableAnswers[0] || '';

  for (const target of normalizedAnswers) {
    const dist = getLevenshteinDistance(normalizedUser, target);
    if (dist < minDistance) {
      minDistance = dist;
      bestMatch = target;
    }
  }

  // Detect if word is completely wrong or unrelated (distance >= length of target, or > 4 letters wrong)
  const isCompletelyDifferent =
    minDistance > 4 || minDistance >= Math.max(bestMatch.length, normalizedUser.length) - 1;

  if (isCompletelyDifferent) {
    return {
      userAnswer: rawInput.trim(),
      matchedAnswer: bestMatch,
      isExact: false,
      isAcceptable: false,
      charErrors: minDistance,
      penalty: maxScore,
      scoreAwarded: 0,
      maxScore,
      explanation: `Sai từ hoặc sai dạng từ loại. Đáp án chuẩn là "${bestMatch}".`,
      diffBreakdown: `Sai hoàn toàn (Khác ${minDistance} ký tự)`,
      score: 0,
      maxPossible: maxScore,
      feedbackVi: `Sai từ hoặc sai dạng từ loại. Đáp án chuẩn là "${bestMatch}". (0đ)`,
      isCorrect: false,
    };
  }

  // Calculate penalty based on exam question count rules
  // Rule:
  // For 5 or 7 questions: 1 char error = -0.3. 2+ char error = 0.3 * charErrors.
  // For 10, 12 questions (or more): 1 char error = -0.15. 2+ char error = 0.15 * charErrors.
  const penaltyPerChar = totalQuestionsInExam <= 7 ? 0.3 : 0.15;
  const rawPenalty = minDistance * penaltyPerChar;
  const penalty = parseFloat(rawPenalty.toFixed(2));
  const scoreAwarded = Math.max(0, parseFloat((maxScore - penalty).toFixed(2)));

  const explanation = `Phát hiện ${minDistance} lỗi chính tả so với đáp án "${bestMatch}". Bị trừ ${penalty} điểm.`;

  return {
    userAnswer: rawInput.trim(),
    matchedAnswer: bestMatch,
    isExact: false,
    isAcceptable: false,
    charErrors: minDistance,
    penalty,
    scoreAwarded,
    maxScore,
    explanation,
    diffBreakdown: `Sai ${minDistance} ký tự (Trừ ${penalty}đ)`,
    score: scoreAwarded,
    maxPossible: maxScore,
    feedbackVi: explanation,
    isCorrect: scoreAwarded > 0 && minDistance === 0,
  };
}

/**
 * Midterm Word Form scoring algorithm according to exact user brief:
 * - Mỗi câu tối đa 0.25 điểm (4 câu = 1.0 điểm)
 * - Sai 1 chữ trừ 0.05 điểm
 * - Nếu trừ hết 0.25 điểm thì ngưng (tối thiểu 0 điểm, không trừ âm)
 */
export function scoreMidtermWordFormAnswer(
  rawInput: string,
  targetAnswerOrList: string | string[],
  extraAcceptableAnswers?: string[]
): WordFormScoreResult {
  const maxScore = 0.25;
  const normalizedUser = normalizeWord(rawInput);

  let acceptableAnswers: string[] = [];
  if (Array.isArray(targetAnswerOrList)) {
    acceptableAnswers = [...targetAnswerOrList];
  } else if (typeof targetAnswerOrList === 'string') {
    acceptableAnswers = [targetAnswerOrList];
  }
  if (Array.isArray(extraAcceptableAnswers)) {
    acceptableAnswers = [...acceptableAnswers, ...extraAcceptableAnswers];
  }
  acceptableAnswers = Array.from(new Set(acceptableAnswers.filter(Boolean)));
  if (acceptableAnswers.length === 0) {
    acceptableAnswers = [''];
  }

  const defaultTarget = acceptableAnswers[0] || '';

  // 1. Bỏ trống câu trả lời
  if (!normalizedUser) {
    return {
      userAnswer: '',
      matchedAnswer: defaultTarget,
      isExact: false,
      isAcceptable: false,
      charErrors: defaultTarget.length,
      penalty: 0.25,
      scoreAwarded: 0,
      maxScore: 0.25,
      explanation: 'Chưa nhập câu trả lời. (Trừ hết 0.25đ)',
      diffBreakdown: 'Bỏ trống (0.00/0.25đ)',
      score: 0,
      maxPossible: 0.25,
      feedbackVi: `Chưa điền câu trả lời. Đáp án chuẩn: "${defaultTarget}". (0.00/0.25đ)`,
      isCorrect: false,
    };
  }

  const normalizedAnswers = acceptableAnswers.map(normalizeWord);

  // 2. Trùng khớp chính xác 100%
  const exactIndex = normalizedAnswers.findIndex((ans) => ans === normalizedUser);
  if (exactIndex !== -1) {
    return {
      userAnswer: rawInput.trim(),
      matchedAnswer: acceptableAnswers[exactIndex],
      isExact: true,
      isAcceptable: true,
      charErrors: 0,
      penalty: 0,
      scoreAwarded: 0.25,
      maxScore: 0.25,
      explanation: 'Chính xác 100%! Đạt trọn vẹn 0.25 điểm.',
      diffBreakdown: 'Chính xác (+0.25đ)',
      score: 0.25,
      maxPossible: 0.25,
      feedbackVi: 'Chính xác 100%! Đạt trọn vẹn 0.25 điểm.',
      isCorrect: true,
    };
  }

  // 3. Tìm đáp án gần nhất qua khoảng cách Levenshtein
  let minDistance = Infinity;
  let bestMatch = acceptableAnswers[0] || '';

  for (const target of normalizedAnswers) {
    const dist = getLevenshteinDistance(normalizedUser, target);
    if (dist < minDistance) {
      minDistance = dist;
      bestMatch = target;
    }
  }

  // Quy tắc Giữa kì: Sai 1 chữ trừ 0.05đ. Trừ hết 0.25 điểm thì ngưng.
  const rawPenalty = minDistance * 0.05;
  const penalty = parseFloat(Math.min(0.25, rawPenalty).toFixed(2));
  const scoreAwarded = parseFloat(Math.max(0, 0.25 - penalty).toFixed(2));

  let explanation = '';
  if (minDistance >= 5 || scoreAwarded === 0) {
    explanation = `Sai từ hoặc sai ${minDistance} chữ (trừ hết 0.25đ thì ngưng). Đạt 0.00/0.25 điểm. Đáp án chuẩn: "${bestMatch}".`;
  } else {
    explanation = `Sai ${minDistance} chữ (mỗi chữ trừ 0.05đ -> trừ ${penalty}đ). Đạt ${scoreAwarded}/0.25 điểm. Đáp án chuẩn: "${bestMatch}".`;
  }

  return {
    userAnswer: rawInput.trim(),
    matchedAnswer: bestMatch,
    isExact: false,
    isAcceptable: false,
    charErrors: minDistance,
    penalty,
    scoreAwarded,
    maxScore: 0.25,
    explanation,
    diffBreakdown: `Sai ${minDistance} chữ (Trừ ${penalty}đ)`,
    score: scoreAwarded,
    maxPossible: 0.25,
    feedbackVi: explanation,
    isCorrect: scoreAwarded > 0 && minDistance === 0,
  };
}

