import { Question } from '../types';

/**
 * Returns the standard clean word/phrase for a question's correct answer.
 * If the question has multiple choice options and correctAnswer is 'B',
 * this returns the actual word (e.g. 'avoided', 'consumed', 'looks').
 * If the question is a text-entry question (tenses, word_form), it returns the clean target word.
 */
export function getStandardCleanWord(q: Question): string {
  // 1. If explicit text answer specified, always prefer it
  if (q.expectedTextAnswer && q.expectedTextAnswer.trim()) {
    return q.expectedTextAnswer.trim();
  }

  const raw = (q.correctAnswer || '').trim();
  const upper = raw.toUpperCase();

  // 2. If it's a letter A/B/C/D and options exist
  if (['A', 'B', 'C', 'D'].includes(upper) && q.options && q.options.length > 0) {
    const idx = ['A', 'B', 'C', 'D'].indexOf(upper);
    const opt = q.options[idx];
    if (opt) {
      // Remove 'A. ', 'B. ' prefix and HTML tags like <u>ed</u>
      const textOnly = opt.replace(/^[A-D]\.\s*/i, '').replace(/<[^>]+>/g, '').trim();
      if (textOnly) return textOnly;
    }
  }

  // 3. If raw answer has 'A. ...' prefix or HTML tags
  const stripped = raw.replace(/^[A-D]\.\s*/i, '').replace(/<[^>]+>/g, '').trim();
  if (stripped) return stripped;

  return raw;
}

/**
 * Returns full standard display information:
 * - wordOnly: 'avoided' or 'You must finish your homework before going to bed.'
 * - fullDisplay: 'avoided (B)' or 'looks (A)'
 * - letter: 'B' (if option-based)
 */
export function getStandardAnswerDisplay(q: Question): {
  wordOnly: string;
  fullDisplay: string;
  letter?: string;
  rawAnswer: string;
} {
  const raw = (q.correctAnswer || '').trim();
  const upper = raw.toUpperCase();
  const expectedText = q.expectedTextAnswer?.trim();

  // 1. If it's an option letter A/B/C/D
  if (['A', 'B', 'C', 'D'].includes(upper) && q.options && q.options.length > 0) {
    const idx = ['A', 'B', 'C', 'D'].indexOf(upper);
    const opt = q.options[idx] || '';
    const wordFromOpt = opt.replace(/^[A-D]\.\s*/i, '').replace(/<[^>]+>/g, '').trim();
    const word = expectedText || wordFromOpt || upper;
    return {
      wordOnly: word,
      fullDisplay: `${word} (${upper})`,
      letter: upper,
      rawAnswer: raw,
    };
  }

  // 2. If question has expectedTextAnswer
  if (expectedText) {
    // Try to find if one of the options matches this word/sentence to extract letter
    let letter: string | undefined = undefined;
    if (q.options && q.options.length > 0) {
      const target = expectedText.toLowerCase().replace(/[.,;!?]+$/g, '').trim();
      const foundIdx = q.options.findIndex((opt) => {
        const clean = opt.replace(/^[A-D]\.\s*/i, '').replace(/<[^>]+>/g, '').toLowerCase().replace(/[.,;!?]+$/g, '').trim();
        return clean === target;
      });
      if (foundIdx !== -1) {
        letter = ['A', 'B', 'C', 'D'][foundIdx];
      }
    }
    return {
      wordOnly: expectedText,
      fullDisplay: letter ? `${expectedText} (${letter})` : expectedText,
      letter,
      rawAnswer: raw,
    };
  }

  // 3. Fallback: clean rawAnswer
  const clean = raw.replace(/^[A-D]\.\s*/i, '').replace(/<[^>]+>/g, '').trim();
  return {
    wordOnly: clean,
    fullDisplay: clean,
    rawAnswer: raw,
  };
}

