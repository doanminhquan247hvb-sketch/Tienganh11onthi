import { EloTier, EloChangeResult } from '../types';

interface ScoreRange {
  minScore: number;
  maxScore: number;
  minDelta: number;
  maxDelta: number;
}

export function getEloTier(elo: number): EloTier {
  if (elo < 500) return 'A0';
  if (elo < 1000) return 'A1';
  if (elo < 1300) return 'A2';
  if (elo < 1500) return 'B1';
  if (elo < 1700) return 'B2';
  return 'B2+';
}

export function getTierNameVi(tier: EloTier): string {
  switch (tier) {
    case 'A0':
      return 'A0 - Mới bắt đầu (Khởi điểm)';
    case 'A1':
      return 'A1 - Sơ cấp (Căn bản)';
    case 'A2':
      return 'A2 - Tiền trung cấp';
    case 'B1':
      return 'B1 - Trung cấp (Chuẩn THPT 11)';
    case 'B2':
      return 'B2 - Trung cấp nâng cao';
    case 'B2+':
      return 'B2+ - Xuất sắc / Đỉnh cao';
  }
}

export function getTierColor(tier: EloTier): {
  bg: string;
  text: string;
  border: string;
  badgeBg: string;
} {
  switch (tier) {
    case 'A0':
      return {
        bg: 'bg-slate-50',
        text: 'text-slate-700',
        border: 'border-slate-300',
        badgeBg: 'bg-slate-200 text-slate-800',
      };
    case 'A1':
      return {
        bg: 'bg-emerald-50',
        text: 'text-emerald-700',
        border: 'border-emerald-300',
        badgeBg: 'bg-emerald-100 text-emerald-800',
      };
    case 'A2':
      return {
        bg: 'bg-cyan-50',
        text: 'text-cyan-700',
        border: 'border-cyan-300',
        badgeBg: 'bg-cyan-100 text-cyan-800',
      };
    case 'B1':
      return {
        bg: 'bg-indigo-50',
        text: 'text-indigo-700',
        border: 'border-indigo-300',
        badgeBg: 'bg-indigo-100 text-indigo-800',
      };
    case 'B2':
      return {
        bg: 'bg-purple-50',
        text: 'text-purple-700',
        border: 'border-purple-300',
        badgeBg: 'bg-purple-100 text-purple-800',
      };
    case 'B2+':
      return {
        bg: 'bg-gradient-to-r from-amber-50 to-orange-50',
        text: 'text-amber-800',
        border: 'border-amber-400',
        badgeBg: 'bg-gradient-to-r from-amber-400 to-yellow-500 text-amber-950 font-black',
      };
  }
}

export function calculateEloChange(currentElo: number, score: number): EloChangeResult {
  const safeScore = Math.max(0, Math.min(10, score));
  const safeElo = Math.max(0, Math.min(2000, currentElo));

  let ranges: ScoreRange[] = [];

  if (safeElo < 500) {
    // 0 - 500 elo (A0)
    ranges = [
      { minScore: 0, maxScore: 1, minDelta: 0, maxDelta: 15 },
      { minScore: 1, maxScore: 2, minDelta: 15, maxDelta: 30 },
      { minScore: 2, maxScore: 3, minDelta: 30, maxDelta: 45 },
      { minScore: 3, maxScore: 4, minDelta: 40, maxDelta: 60 },
      { minScore: 4, maxScore: 5, minDelta: 55, maxDelta: 75 },
      { minScore: 5, maxScore: 6.5, minDelta: 60, maxDelta: 80 },
      { minScore: 6.5, maxScore: 8, minDelta: 75, maxDelta: 90 },
      { minScore: 8, maxScore: 10, minDelta: 90, maxDelta: 120 },
    ];
  } else if (safeElo < 1000) {
    // 500 - 1000 elo (A1)
    ranges = [
      { minScore: 0, maxScore: 1, minDelta: -20, maxDelta: -10 },
      { minScore: 1, maxScore: 2, minDelta: -10, maxDelta: 0 },
      { minScore: 2, maxScore: 3, minDelta: 0, maxDelta: 5 },
      { minScore: 3, maxScore: 4, minDelta: 5, maxDelta: 30 },
      { minScore: 4, maxScore: 5, minDelta: 30, maxDelta: 50 },
      { minScore: 5, maxScore: 6.5, minDelta: 55, maxDelta: 70 },
      { minScore: 6.5, maxScore: 8, minDelta: 75, maxDelta: 90 },
      { minScore: 8, maxScore: 10, minDelta: 90, maxDelta: 120 },
    ];
  } else if (safeElo < 1300) {
    // 1000 - 1300 elo (A2)
    ranges = [
      { minScore: 0, maxScore: 1, minDelta: -50, maxDelta: -40 },
      { minScore: 1, maxScore: 2, minDelta: -30, maxDelta: -25 },
      { minScore: 2, maxScore: 3, minDelta: -15, maxDelta: -5 },
      { minScore: 3, maxScore: 4, minDelta: 5, maxDelta: 10 },
      { minScore: 4, maxScore: 5, minDelta: 15, maxDelta: 25 },
      { minScore: 5, maxScore: 6.5, minDelta: 30, maxDelta: 45 },
      { minScore: 6.5, maxScore: 8, minDelta: 60, maxDelta: 80 },
      { minScore: 8, maxScore: 10, minDelta: 100, maxDelta: 130 },
    ];
  } else if (safeElo < 1500) {
    // 1300 - 1500 elo (B1)
    ranges = [
      { minScore: 0, maxScore: 1, minDelta: -60, maxDelta: -45 },
      { minScore: 1, maxScore: 2, minDelta: -45, maxDelta: -30 },
      { minScore: 2, maxScore: 3, minDelta: -30, maxDelta: -15 },
      { minScore: 3, maxScore: 4, minDelta: -20, maxDelta: -10 },
      { minScore: 4, maxScore: 5, minDelta: -10, maxDelta: 0 },
      { minScore: 5, maxScore: 6, minDelta: 15, maxDelta: 30 },
      { minScore: 6, maxScore: 7, minDelta: 25, maxDelta: 40 },
      { minScore: 7, maxScore: 8, minDelta: 30, maxDelta: 55 },
      { minScore: 8, maxScore: 10, minDelta: 60, maxDelta: 70 },
    ];
  } else {
    // 1500 - 2000 (B2, B2+)
    ranges = [
      { minScore: 0, maxScore: 1, minDelta: -83, maxDelta: -69 },
      { minScore: 1, maxScore: 2, minDelta: -65, maxDelta: -52 },
      { minScore: 2, maxScore: 3, minDelta: -45, maxDelta: -31 },
      { minScore: 3, maxScore: 4, minDelta: -31, maxDelta: -19 },
      { minScore: 4, maxScore: 5, minDelta: -19, maxDelta: 0 },
      { minScore: 5, maxScore: 6, minDelta: 5, maxDelta: 20 },
      { minScore: 6, maxScore: 7, minDelta: 20, maxDelta: 30 },
      { minScore: 7, maxScore: 8, minDelta: 30, maxDelta: 45 },
      { minScore: 8, maxScore: 10, minDelta: 60, maxDelta: 70 },
    ];
  }

  // Find corresponding score range
  const matchedRange =
    ranges.find((r) => safeScore >= r.minScore && (safeScore < r.maxScore || (r.maxScore === 10 && safeScore === 10))) ||
    ranges[ranges.length - 1];

  const scoreSpan = matchedRange.maxScore - matchedRange.minScore || 1;
  const ratio = (safeScore - matchedRange.minScore) / scoreSpan;
  const rawDelta = matchedRange.minDelta + ratio * (matchedRange.maxDelta - matchedRange.minDelta);
  let delta = Math.round(rawDelta);

  // Quy tắc mới: Từ mốc 1000 ELO trở lên, trừ bớt 12% điểm cộng (positive gains) để chống lạm phát ELO
  if (safeElo >= 1000 && delta > 0) {
    delta = Math.round(delta * 0.88);
  }

  const newElo = Math.max(0, Math.min(2000, safeElo + delta));
  const oldTier = getEloTier(safeElo);
  const newTier = getEloTier(newElo);

  return {
    oldElo: safeElo,
    newElo,
    delta,
    oldTier,
    newTier,
    tierNameVi: getTierNameVi(newTier),
    score: safeScore,
  };
}
